import { widget, prop } from '@zos/ui'
import { gettext, format } from '../../lib/utils/i18n.js'
import { safeDeviceInfo } from '../../lib/utils/deviceInfo.js'
import { replace } from '@zos/router'
import ScreenReader from '../../lib/core/readerProxy.js'
import { saveSettings } from '../../lib/core/config.js'

import { ZSRPage } from '../../lib/core/zsrPage.js'
import { createWidget, createChild } from '../../lib/core/zsrWidgets.js'
const { width, height } = safeDeviceInfo()

function createToggle(root, y, label, checked, onChange) {
  createChild(root, widget.TEXT, {
    x: 40,
    y: y,
    w: width - 150,
    h: 60,
    text: label,
    color: 0xffffff,
    text_size: 24,
    align_v: 2
  })

  createChild(root, widget.SLIDE_SWITCH, {
    x: width - 110,
    y: y + 10,
    w: 80,
    h: 40,
    checked: checked,
    select_bg: 0x00aa00,
    unselect_bg: 0x666666,
    checked_change_func: (val) => {
      onChange(val)
    }
  })
}

function createStepper(root, y, label, value, min, max, onChange) {
  let currentVal = value

  const textWidget = createChild(root, widget.TEXT, {
    x: 40,
    y: y,
    w: width - 80,
    h: 40,
    text: `${label}: ${currentVal.toFixed(1)}`,
    color: 0xffffff,
    text_size: 20,
    align_v: 2
  })

  createChild(root, widget.BUTTON, {
    x: 40,
    y: y + 45,
    w: (width - 100) / 2,
    h: 50,
    text: '-',
    color: 0xffffff,
    normal_color: 0x333333,
    press_color: 0x666666,
    radius: 25,
    click_func: () => {
      if (currentVal > min) {
        currentVal = Math.max(min, Math.round((currentVal - 0.1) * 10) / 10)
        textWidget.setProperty(prop.TEXT, `${label}: ${currentVal.toFixed(1)}`)
        onChange(currentVal)
      }
    }
  })

  createChild(root, widget.BUTTON, {
    x: 40 + (width - 100) / 2 + 20,
    y: y + 45,
    w: (width - 100) / 2,
    h: 50,
    text: '+',
    color: 0xffffff,
    normal_color: 0x333333,
    press_color: 0x666666,
    radius: 25,
    click_func: () => {
      if (currentVal < max) {
        currentVal = Math.min(max, Math.round((currentVal + 0.1) * 10) / 10)
        textWidget.setProperty(prop.TEXT, `${label}: ${currentVal.toFixed(1)}`)
        onChange(currentVal)
      }
    }
  })
}

export default ZSRPage({
  onInit() {
    if (!globalThis.ScreenReaderConfig) {
      globalThis.ScreenReaderConfig = {}
    }
  },

  build() {
    const root = createWidget(widget.GROUP, {
      x: 0,
      y: 0,
      w: width,
      h: height
    })

    const config = globalThis.ScreenReaderConfig

    createChild(root, widget.TEXT, {
      x: 0,
      y: 20,
      w: width,
      h: 50,
      text: gettext('Speech Settings'),
      color: 0xffffff,
      align_h: 2,
      align_v: 2,
      text_size: 28
    })

    // Speech Rate
    createStepper(root, 80, gettext('Speech Rate'), config.speechRate ?? 1.0, 0.5, 3.0, (val) => {
      config.speechRate = val
      ScreenReader.tts.setRate(val)
      saveSettings(config)
    })

    // Speech Pitch
    createStepper(
      root,
      185,
      gettext('Speech Pitch'),
      config.speechPitch ?? 1.0,
      0.5,
      2.0,
      (val) => {
        config.speechPitch = val
        ScreenReader.tts.setPitch(val)
        saveSettings(config)
      }
    )

    // Toggles
    createToggle(root, 290, gettext('Read Status Bar'), !!config.readStatusBar, (val) => {
      config.readStatusBar = val
      saveSettings(config)
    })

    createToggle(root, 360, gettext('Read Progress'), !!config.readProgressBars, (val) => {
      config.readProgressBars = val
      saveSettings(config)
    })

    createToggle(root, 430, gettext('Read Hints'), !!config.readUsageHints, (val) => {
      config.readUsageHints = val
      saveSettings(config)
    })

    // TTS Engine Selector
    const engine = config.primaryTTSEngine || 'espeak'
    createChild(root, widget.BUTTON, {
      x: 40,
      y: 510,
      w: width - 80,
      h: 60,
      text: `${gettext('Engine')}: ${engine.toUpperCase()}`,
      color: 0xffffff,
      normal_color: 0x333333,
      press_color: 0x555555,
      radius: 30,
      click_func: () => {
        const next = engine === 'native' ? 'espeak' : 'native'
        config.primaryTTSEngine = next
        saveSettings(config)
        ScreenReader.speak(format(gettext('TTS engine set to {0}'), next), { priority: 'high' })
        replace({ url: 'page/settings/Speech' })
      }
    })

    return root
  }
})
